//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

import Foundation
import Viperit

class ___VARIABLE_ViperitModuleName___Router: Router {
}

// MARK: - VIPER COMPONENTS API (Auto-generated code)
private extension ___VARIABLE_ViperitModuleName___Router {
    var presenter: ___VARIABLE_ViperitModuleName___Presenter {
        return _presenter as! ___VARIABLE_ViperitModuleName___Presenter
    }
}
