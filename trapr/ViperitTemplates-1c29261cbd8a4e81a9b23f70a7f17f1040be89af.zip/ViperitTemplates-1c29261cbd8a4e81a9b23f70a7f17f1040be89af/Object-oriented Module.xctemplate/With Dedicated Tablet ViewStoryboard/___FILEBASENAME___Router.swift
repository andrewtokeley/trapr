//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

import Foundation
import Viperit

class ___FILEBASENAMEASIDENTIFIER___Router: Router {
}

// MARK: - VIPER COMPONENTS API (Auto-generated code)
private extension ___FILEBASENAMEASIDENTIFIER___Router {
    var presenter: ___FILEBASENAMEASIDENTIFIER___Presenter {
        return _presenter as! ___FILEBASENAMEASIDENTIFIER___Presenter
    }
}
